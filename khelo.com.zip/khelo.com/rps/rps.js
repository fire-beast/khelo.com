const choices = ["rock", "paper", "scissors"];
const resultDisplay = document.getElementById("result");

function getComputerChoice() {
    return choices[Math.floor(Math.random() * choices.length)];
}

function determineWinner(playerChoice, computerChoice) {
    if (playerChoice === computerChoice) {
        return "It's a draw!";
    }
    if (
        (playerChoice === "rock" && computerChoice === "scissors") ||
        (playerChoice === "paper" && computerChoice === "rock") ||
        (playerChoice === "scissors" && computerChoice === "paper")
    ) {
        return "You win!";
    }
    return "Computer wins!";
}

function playGame(playerChoice) {
    const computerChoice = getComputerChoice();
    const resultMessage = `You chose ${playerChoice}, computer chose ${computerChoice}. ${determineWinner(playerChoice, computerChoice)}`;
    resultDisplay.innerText = resultMessage;
}

document.querySelectorAll(".choice").forEach(button => {
    button.addEventListener("click", () => playGame(button.getAttribute("data-choice")));
});

document.getElementById("resetButton").addEventListener("click", () => {
    resultDisplay.innerText = "Make a choice to start the game!";
});
