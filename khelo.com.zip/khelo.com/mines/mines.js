let balance = 5000;
let betAmount = 0;
let mines = [];
let clearedTiles = 0;
let earnings = 0;
let multiplier = 1.0;
let gameStarted = false;

function startGame() {
  const betInput = document.getElementById("bet-amount").value;
  betAmount = parseFloat(betInput).toFixed(3);

  if (!betAmount || betAmount < 1 || betAmount > balance) {
    alert("Please enter a valid bet amount within your balance.");
    return;
  }

  balance = (balance - betAmount).toFixed(3);
  document.getElementById("balance").textContent = balance;

  earnings = parseFloat(betAmount);
  clearedTiles = 0;
  multiplier = 1.0;
  gameStarted = true;
  mines = generateMines(3, 25);
  
  createGrid();
  updateEarningsDisplay();
}

function generateMines(count, gridSize) {
  const minesArray = [];
  while (minesArray.length < count) {
    const minePosition = Math.floor(Math.random() * gridSize);
    if (!minesArray.includes(minePosition)) {
      minesArray.push(minePosition);
    }
  }
  return minesArray;
}

function createGrid() {
  const gridContainer = document.getElementById("mines-grid");
  gridContainer.innerHTML = '';
  
  for (let i = 0; i < 25; i++) {
    const tile = document.createElement("div");
    tile.classList.add("tile");
    tile.addEventListener("click", () => revealTile(i, tile));
    gridContainer.appendChild(tile);
  }
}

function revealTile(index, tile) {
  if (!gameStarted || tile.classList.contains("clicked")) return;

  tile.classList.add("clicked");

  if (mines.includes(index)) {
    tile.textContent = "💣";
    tile.style.color = "red";
    revealBoard();
    document.getElementById("explosion-sound").play();
    alert("You hit a mine! Game over.");
    gameStarted = false;
    earnings = 0;  // Reset earnings after losing
    multiplier = 1.0;  // Reset multiplier after losing
    updateEarningsDisplay();
    return;
  } 

  tile.textContent = "💎";
  tile.style.color = "white";
  clearedTiles++;
  multiplier += 0.1;
  earnings = betAmount * multiplier;
  document.getElementById("diamond-sound").play();
  updateEarningsDisplay();
}

function revealBoard() {
  const gridContainer = document.getElementById("mines-grid").children;
  
  for (let i = 0; i < 25; i++) {
    const tile = gridContainer[i];
    
    if (mines.includes(i)) {
      tile.textContent = "💣";
      tile.style.color = "red";
    } else if (!tile.classList.contains("clicked")) {
      tile.textContent = "💎";
      tile.style.color = "white";
    }
  }
}

function updateEarningsDisplay() {
  const earningsDisplay = document.getElementById("earnings-display");
  earningsDisplay.textContent = `Current Earning: ${multiplier.toFixed(1)}x (${earnings.toFixed(2)} INR)`;
}

function cashout() {
  if (!gameStarted) {
    alert("No active game to cash out from.");
    return;
  }

  balance = (parseFloat(balance) + parseFloat(earnings)).toFixed(3);
  document.getElementById("balance").textContent = balance;
  alert(`You cashed out with earnings of ${earnings.toFixed(2)} INR!`);
  gameStarted = false;
  earnings = 0;  // Reset earnings after cashing out
  multiplier = 1.0;  // Reset multiplier after cashing out
  updateEarningsDisplay();
}
