let secretNumber;
let guessCount = 0;

function startGame() {
    secretNumber = Math.floor(Math.random() * 50) + 1; // Random number between 1 and 50
    guessCount = 0;
    document.getElementById("attempts").textContent = guessCount;
    document.getElementById("message").textContent = "";
}

function checkGuess() {
    let userGuess = parseInt(document.getElementById("userGuess").value);
    let message = document.getElementById("message");
    let attempts = document.getElementById("attempts");

    if (isNaN(userGuess) || userGuess < 1 || userGuess > 50) {
        message.textContent = "Please enter a valid number between 1 and 50.";
        message.classList.remove('success');
        message.style.color = "#ff6347";
        return;
    }

    guessCount++;
    attempts.textContent = guessCount;

    if (userGuess === secretNumber) {
        message.textContent = `Congratulations! You guessed the number in ${guessCount} tries!`;
        message.classList.add('success');
        message.style.color = "#4CAF50";
    } else if (userGuess < secretNumber) {
        message.textContent = "Too low! Try again.";
        message.style.color = "#ff6347";
    } else {
        message.textContent = "Too high! Try again.";
        message.style.color = "#ff6347";
    }

    document.getElementById("userGuess").value = "";
    document.getElementById("userGuess").focus();
}

function resetGame() {
    startGame();
    document.getElementById("userGuess").value = "";
    document.getElementById("message").textContent = "";
}

// Start the game when the page loads
startGame();
