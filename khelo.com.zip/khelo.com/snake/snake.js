const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const boxSize = 20; // Size of each box in the grid
const rows = canvas.height / boxSize;
const cols = canvas.width / boxSize;

let snake;
let food;
let score;
let dx;
let dy;
let gameInterval;

const eatSound = document.getElementById("eatSound");
const gameOverSound = document.getElementById("gameOverSound");

// Initialize game
function startGame() {
    snake = [{ x: cols / 2 * boxSize, y: rows / 2 * boxSize }];
    food = generateFood();
    dx = boxSize;
    dy = 0;
    score = 0;
    clearInterval(gameInterval);
    gameInterval = setInterval(drawGame, 80); // Update game every 80ms for smoother motion
    document.getElementById("score").innerText = `Score: ${score}`;
}

// Draw game elements
function drawGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Move snake
    const head = { x: snake[0].x + dx, y: snake[0].y + dy };
    snake.unshift(head);

    // Check if snake has eaten the food
    if (head.x === food.x && head.y === food.y) {
        score++;
        document.getElementById("score").innerText = `Score: ${score}`;
        eatSound.play();
        food = generateFood();
        canvas.style.boxShadow = "0 0 20px #ff4500, 0 0 30px #ff4500";
        setTimeout(() => {
            canvas.style.boxShadow = "0 0 15px #00ff00, 0 0 30px #00ff00";
        }, 200);
    } else {
        snake.pop(); // Remove tail if no food eaten
    }

    // Check for collision
    if (checkCollision()) {
        gameOverSound.play();
        alert("Game Over! Your score: " + score);
        clearInterval(gameInterval);
        return;
    }

    // Draw snake and food
    drawSnake();
    drawFood();
}

// Draw snake
function drawSnake() {
    ctx.fillStyle = "#00ff00";
    ctx.strokeStyle = "#222";
    snake.forEach((segment, index) => {
        ctx.fillRect(segment.x, segment.y, boxSize, boxSize);
        ctx.strokeRect(segment.x, segment.y, boxSize, boxSize);
    });
}

// Draw food
function drawFood() {
    ctx.fillStyle = "#ff4500";
    ctx.fillRect(food.x, food.y, boxSize, boxSize);
    ctx.strokeStyle = "#222";
    ctx.strokeRect(food.x, food.y, boxSize, boxSize);
}

// Generate food at random location
function generateFood() {
    return {
        x: Math.floor(Math.random() * cols) * boxSize,
        y: Math.floor(Math.random() * rows) * boxSize
    };
}

// Check for collisions with wall or itself
function checkCollision() {
    const head = snake[0];
    return (
        head.x < 0 || head.x >= canvas.width || head.y < 0 || head.y >= canvas.height ||
        snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y)
    );
}

// Control snake direction
document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowUp" && dy === 0) {
        dx = 0;
        dy = -boxSize;
    } else if (event.key === "ArrowDown" && dy === 0) {
        dx = 0;
        dy = boxSize;
    } else if (event.key === "ArrowLeft" && dx === 0) {
        dx = -boxSize;
        dy = 0;
    } else if (event.key === "ArrowRight" && dx === 0) {
        dx = boxSize;
        dy = 0;
    }
});
