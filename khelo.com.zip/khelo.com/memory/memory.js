const cardImages = [
    '🍎', '🍎',
    '🍌', '🍌',
    '🍇', '🍇',
    '🍒', '🍒',
    '🍉', '🍉',
    '🍊', '🍊',
    '🍓', '🍓',
    '🍍', '🍍',
];

let board = [];
let firstCard, secondCard;
let lockBoard = false;
let matchedCards = 0;

// Shuffle cards
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function createBoard() {
    shuffle(cardImages);
    const gameBoard = document.getElementById('game-board');
    gameBoard.innerHTML = '';
    board = cardImages.map((image, index) => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.setAttribute('data-card', image);
        card.addEventListener('click', () => handleCardClick(card, image));
        gameBoard.appendChild(card);
        return card;
    });
}

function handleCardClick(card, image) {
    if (lockBoard || card.classList.contains('flipped')) return;

    card.classList.add('flipped');
    card.innerText = image;

    if (!firstCard) {
        firstCard = card;
    } else {
        secondCard = card;
        lockBoard = true;
        checkForMatch();
    }
}

function checkForMatch() {
    if (firstCard.dataset.card === secondCard.dataset.card) {
        matchedCards += 2;
        resetBoard();
        if (matchedCards === cardImages.length) {
            document.getElementById('status').innerText = 'You win! 🎉';
            setTimeout(resetGame, 2000);
        }
    } else {
        setTimeout(() => {
            firstCard.classList.remove('flipped');
            firstCard.innerText = '';
            secondCard.classList.remove('flipped');
            secondCard.innerText = '';
            resetBoard();
        }, 1000);
    }
}

function resetBoard() {
    [firstCard, secondCard] = [null, null];
    lockBoard = false;
}

function resetGame() {
    matchedCards = 0;
    document.getElementById('status').innerText = '';
    createBoard();
}

document.getElementById('resetButton').addEventListener('click', resetGame);

// Initialize the game
createBoard();
