const colors = ['red', 'blue', 'green', 'yellow'];
let sequence = [];
let userInput = [];
let round = 0;
let isGameActive = false;

const roundDisplay = document.getElementById('roundDisplay');
const roundNumber = document.getElementById('roundNumber');
const statusMessage = document.getElementById('statusMessage');
const startButton = document.getElementById('startButton');

// Start the game
startButton.addEventListener('click', () => {
    startGame();
});

function startGame() {
    sequence = [];  // Reset sequence
    round = 0;      // Reset round number
    isGameActive = true;  // Set game state to active
    statusMessage.textContent = ''; // Reset status message
    nextRound();   // Move to the first round
}

function nextRound() {
    userInput = [];  // Reset user input
    round++;         // Increment round number
    roundNumber.textContent = round;  // Update round display
    roundDisplay.classList.remove('hidden');

    // Display round number
    setTimeout(() => {
        roundDisplay.classList.add('hidden');
        addColorToSequence();  // Add new color to sequence
        playSequence();        // Play the current sequence
    }, 1000);
}

function addColorToSequence() {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    sequence.push(randomColor);  // Add random color to the sequence
}

function playSequence() {
    let index = 0;

    const interval = setInterval(() => {
        flashColor(sequence[index]);  // Flash color in sequence
        index++;

        if (index >= sequence.length) {
            clearInterval(interval);  // Clear interval when sequence is done
            listenForUserInput();     // Start listening for user input
        }
    }, 1000);
}

function flashColor(color) {
    const colorDiv = document.getElementById(`color${colors.indexOf(color) + 1}`);
    colorDiv.style.opacity = '1';  // Make color fully visible

    setTimeout(() => {
        colorDiv.style.opacity = '0.7';  // Dim color after half a second
    }, 500);
}

function listenForUserInput() {
    // Clear any previous event listeners to avoid multiple bindings
    colors.forEach((color, index) => {
        const colorDiv = document.getElementById(`color${index + 1}`);
        // Use a named function to ensure it's removed properly
        colorDiv.onclick = () => handleUserInput(color);
    });
}

function handleUserInput(color) {
    if (!isGameActive) return;  // Ignore input if game is not active

    userInput.push(color);  // Add user's input
    flashColor(color);  // Flash the selected color

    // Check if user input is correct
    const currentRoundIndex = userInput.length - 1;  // Get the last index of user input
    if (userInput[currentRoundIndex] !== sequence[currentRoundIndex]) {
        // Incorrect input
        statusMessage.textContent = 'Wrong! Game Over.';
        isGameActive = false;  // Set game state to inactive
        return; // Stop further processing
    }

    // Check if the user has completed the round
    if (userInput.length === sequence.length) {
        // If the player completed the round correctly
        if (round === 3) {
            statusMessage.textContent = 'You Win!';  // Player wins after 3 rounds
            isGameActive = false;  // End the game
        } else {
            setTimeout(() => {
                nextRound();  // Proceed to the next round
            }, 1000);
        }
    }
}
