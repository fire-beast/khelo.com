const boardSize = 4;
let board = [];
let isGameWon = false;

const gameBoard = document.getElementById('game-board');
const statusMessage = document.getElementById('statusMessage');

// Initialize the game
function initGame() {
    board = Array.from({ length: boardSize }, () => Array(boardSize).fill(0));
    addRandomTile();
    addRandomTile();
    drawBoard();
    document.addEventListener('keydown', handleKeyPress);
}

// Add a random tile (2 or 4) to an empty spot on the board
function addRandomTile() {
    let emptyTiles = [];
    for (let row = 0; row < boardSize; row++) {
        for (let col = 0; col < boardSize; col++) {
            if (board[row][col] === 0) {
                emptyTiles.push({ row, col });
            }
        }
    }

    if (emptyTiles.length > 0) {
        const { row, col } = emptyTiles[Math.floor(Math.random() * emptyTiles.length)];
        board[row][col] = Math.random() < 0.9 ? 2 : 4;
    }
}

// Draw the game board
function drawBoard() {
    gameBoard.innerHTML = '';
    for (let row = 0; row < boardSize; row++) {
        for (let col = 0; col < boardSize; col++) {
            const tile = document.createElement('div');
            tile.classList.add('tile');
            if (board[row][col] !== 0) {
                tile.textContent = board[row][col];
                tile.dataset.value = board[row][col];

                // Add classes for new tiles and merged tiles for animation
                if (board[row][col] === 2 || board[row][col] === 4) {
                    tile.classList.add('new-tile');
                } else if (board[row][col] > 4) {
                    tile.classList.add('merged-tile');
                }
            }
            gameBoard.appendChild(tile);
        }
    }
}

// Handle key press events for moving tiles
function handleKeyPress(event) {
    if (isGameWon) return; // Stop the game if the user has won

    let moved = false;
    switch (event.key) {
        case 'ArrowUp':
            moved = slideTilesUp();
            break;
        case 'ArrowDown':
            moved = slideTilesDown();
            break;
        case 'ArrowLeft':
            moved = slideTilesLeft();
            break;
        case 'ArrowRight':
            moved = slideTilesRight();
            break;
    }

    if (moved) {
        addRandomTile();
        drawBoard();
        checkGameWon();
        checkGameOver();
    }
}

// Check if the player has won the game by reaching 2048
function checkGameWon() {
    for (let row = 0; row < boardSize; row++) {
        for (let col = 0; col < boardSize; col++) {
            if (board[row][col] === 2048) {
                statusMessage.textContent = 'You Win! Game Over.';
                isGameWon = true;
                return;
            }
        }
    }
}

// Check if there are no moves left and the player has lost
function checkGameOver() {
    for (let row = 0; row < boardSize; row++) {
        for (let col = 0; col < boardSize; col++) {
            if (board[row][col] === 0) return; // Empty tile found, game continues

            // Check adjacent tiles for possible moves
            if (
                (row > 0 && board[row][col] === board[row - 1][col]) ||
                (row < boardSize - 1 && board[row][col] === board[row + 1][col]) ||
                (col > 0 && board[row][col] === board[row][col - 1]) ||
                (col < boardSize - 1 && board[row][col] === board[row][col + 1])
            ) {
                return;
            }
        }
    }

    statusMessage.textContent = 'Game Over. No moves left!';
    document.body.classList.add('game-over');
    document.removeEventListener('keydown', handleKeyPress);
}
// Slide and merge tiles up
function slideTilesUp() {
    let moved = false;
    for (let col = 0; col < boardSize; col++) {
        let mergedRow = -1; // To track if tiles have been merged
        for (let row = 1; row < boardSize; row++) {
            if (board[row][col] !== 0) {
                let targetRow = row;
                while (targetRow > 0 && board[targetRow - 1][col] === 0) {
                    targetRow--;
                }

                if (targetRow > 0 && board[targetRow - 1][col] === board[row][col] && mergedRow !== targetRow - 1) {
                    board[targetRow - 1][col] *= 2;
                    board[row][col] = 0;
                    mergedRow = targetRow - 1;
                    moved = true;
                } else if (targetRow !== row) {
                    board[targetRow][col] = board[row][col];
                    board[row][col] = 0;
                    moved = true;
                }
            }
        }
    }
    return moved;
}

// Slide and merge tiles down
function slideTilesDown() {
    let moved = false;
    for (let col = 0; col < boardSize; col++) {
        let mergedRow = boardSize;
        for (let row = boardSize - 2; row >= 0; row--) {
            if (board[row][col] !== 0) {
                let targetRow = row;
                while (targetRow < boardSize - 1 && board[targetRow + 1][col] === 0) {
                    targetRow++;
                }

                if (targetRow < boardSize - 1 && board[targetRow + 1][col] === board[row][col] && mergedRow !== targetRow + 1) {
                    board[targetRow + 1][col] *= 2;
                    board[row][col] = 0;
                    mergedRow = targetRow + 1;
                    moved = true;
                } else if (targetRow !== row) {
                    board[targetRow][col] = board[row][col];
                    board[row][col] = 0;
                    moved = true;
                }
            }
        }
    }
    return moved;
}

// Slide and merge tiles to the left
function slideTilesLeft() {
    let moved = false;
    for (let row = 0; row < boardSize; row++) {
        let mergedCol = -1;
        for (let col = 1; col < boardSize; col++) {
            if (board[row][col] !== 0) {
                let targetCol = col;
                while (targetCol > 0 && board[row][targetCol - 1] === 0) {
                    targetCol--;
                }

                if (targetCol > 0 && board[row][targetCol - 1] === board[row][col] && mergedCol !== targetCol - 1) {
                    board[row][targetCol - 1] *= 2;
                    board[row][col] = 0;
                    mergedCol = targetCol - 1;
                    moved = true;
                } else if (targetCol !== col) {
                    board[row][targetCol] = board[row][col];
                    board[row][col] = 0;
                    moved = true;
                }
            }
        }
    }
    return moved;
}

// Slide and merge tiles to the right
function slideTilesRight() {
    let moved = false;
    for (let row = 0; row < boardSize; row++) {
        let mergedCol = boardSize;
        for (let col = boardSize - 2; col >= 0; col--) {
            if (board[row][col] !== 0) {
                let targetCol = col;
                while (targetCol < boardSize - 1 && board[row][targetCol + 1] === 0) {
                    targetCol++;
                }

                if (targetCol < boardSize - 1 && board[row][targetCol + 1] === board[row][col] && mergedCol !== targetCol + 1) {
                    board[row][targetCol + 1] *= 2;
                    board[row][col] = 0;
                    mergedCol = targetCol + 1;
                    moved = true;
                } else if (targetCol !== col) {
                    board[row][targetCol] = board[row][col];
                    board[row][col] = 0;
                    moved = true;
                }
            }
        }
    }
    return moved;
}

// Initialize the game on page load
initGame();
