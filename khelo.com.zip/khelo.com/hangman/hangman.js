let words = [
    { word: "Brazil", hint: "Country in South America" },
    { word: "Paris", hint: "Capital of France" },
    { word: "Egypt", hint: "Home of the Pyramids" },
    { word: "Tokyo", hint: "Capital of Japan" },
    { word: "Australia", hint: "Country and a continent" }
];

let currentWord = "";
let guessedWord = "";
let attempts = 6;
let score = 0;  // Score variable
let currentWordIndex = 0;

function startGame() {
    currentWord = words[currentWordIndex].word.toUpperCase();
    guessedWord = "_".repeat(currentWord.length);
    document.getElementById("word-to-guess").textContent = guessedWord.split("").join(" ");
    document.getElementById("attempts-left").textContent = "Attempts Left: " + attempts;
    document.getElementById("hint").textContent = "";
    document.getElementById("message").textContent = "";
    document.getElementById("message").classList.remove("success");
    document.getElementById("score").textContent = "Score: " + score;  // Update score
    generateAlphabetButtons();
}

function generateAlphabetButtons() {
    const lettersContainer = document.getElementById("letters");
    lettersContainer.innerHTML = ""; // Clear previous buttons
    for (let charCode = 65; charCode <= 90; charCode++) {
        let button = document.createElement("button");
        button.textContent = String.fromCharCode(charCode);
        button.onclick = () => guessLetter(String.fromCharCode(charCode));
        lettersContainer.appendChild(button);
    }
}

function guessLetter(letter) {
    if (attempts <= 0 || guessedWord === currentWord) return; // Prevent further guesses

    letter = letter.toUpperCase();
    if (currentWord.includes(letter)) {
        // Correct Guess
        let newGuessedWord = "";
        for (let i = 0; i < currentWord.length; i++) {
            if (currentWord[i] === letter) {
                newGuessedWord += letter;
            } else {
                newGuessedWord += guessedWord[i];
            }
        }
        guessedWord = newGuessedWord;
        document.getElementById("word-to-guess").textContent = guessedWord.split("").join(" ");
        
        if (guessedWord === currentWord) {
            // Increase score on correct word
            score++;
            document.getElementById("score").textContent = "Score: " + score;  // Update score
            document.getElementById("message").textContent = "Great job! Moving on to the next one...";
            document.getElementById("message").classList.add("success");
            document.getElementById("word-to-guess").classList.add("success-word"); // Animation for correct word
            setTimeout(() => {
                currentWordIndex++;
                if (currentWordIndex < words.length) {
                    startGame();
                } else {
                    document.getElementById("message").textContent = "Congratulations! You've completed the game.";
                    document.getElementById("attempts-left").textContent = "";
                }
            }, 2000);
        }
    } else {
        // Incorrect Guess
        attempts--;
        document.getElementById("attempts-left").textContent = "Attempts Left: " + attempts;
        
        if (attempts === 1) {
            document.getElementById("hint").textContent = "Hint: " + words[currentWordIndex].hint; // Show hint
        }
        
        if (attempts <= 0) {
            document.getElementById("message").textContent = "Game Over! The correct word was: " + currentWord;
        }
    }
}

function resetGame() {
    attempts = 6;
    score = 0;  // Reset score
    currentWordIndex = 0;
    startGame();
}

startGame();
