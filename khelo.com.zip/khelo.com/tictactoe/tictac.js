const board = document.getElementById('board');
const statusDisplay = document.getElementById('status');
const resetButton = document.getElementById('resetButton');

let boardState = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X'; // Player is always 'X'
let gameActive = true;

const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

function createBoard() {
    board.innerHTML = '';
    boardState.forEach((cell, index) => {
        const cellElement = document.createElement('div');
        cellElement.classList.add('cell');
        cellElement.innerText = cell;
        cellElement.addEventListener('click', () => handleCellClick(index));
        board.appendChild(cellElement);
    });
}

function handleCellClick(index) {
    if (boardState[index] !== '' || !gameActive) {
        return;
    }

    boardState[index] = currentPlayer;
    checkResult(currentPlayer);  // Check if the player wins after their move
    if (gameActive) {
        computerPlay();
    }
    createBoard();
}

function computerPlay() {
    // Try to win
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (boardState[a] === 'O' && boardState[b] === 'O' && boardState[c] === '') {
            boardState[c] = 'O';
            checkResult('O');
            createBoard();
            return;
        } else if (boardState[a] === 'O' && boardState[c] === 'O' && boardState[b] === '') {
            boardState[b] = 'O';
            checkResult('O');
            createBoard();
            return;
        } else if (boardState[b] === 'O' && boardState[c] === 'O' && boardState[a] === '') {
            boardState[a] = 'O';
            checkResult('O');
            createBoard();
            return;
        }
    }

    // Block player's winning move
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (boardState[a] === 'X' && boardState[b] === 'X' && boardState[c] === '') {
            boardState[c] = 'O';
            checkResult('O');
            createBoard();
            return;
        } else if (boardState[a] === 'X' && boardState[c] === 'X' && boardState[b] === '') {
            boardState[b] = 'O';
            checkResult('O');
            createBoard();
            return;
        } else if (boardState[b] === 'X' && boardState[c] === 'X' && boardState[a] === '') {
            boardState[a] = 'O';
            checkResult('O');
            createBoard();
            return;
        }
    }

    // Choose a random available cell if no winning/blocking move
    const availableCells = boardState.map((cell, index) => cell === '' ? index : null).filter(cell => cell !== null);
    if (availableCells.length > 0) {
        const randomIndex = Math.floor(Math.random() * availableCells.length);
        boardState[availableCells[randomIndex]] = 'O';
        checkResult('O');
    }
}

function checkResult(player) {
    let roundWon = false;
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (boardState[a] === '' || boardState[b] === '' || boardState[c] === '') {
            continue;
        }
        if (boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        statusDisplay.innerText = `Player ${player} wins!`;
        gameActive = false;
        return;
    }

    if (!boardState.includes('')) {
        statusDisplay.innerText = 'It\'s a draw!';
        gameActive = false;
    }
}

resetButton.addEventListener('click', () => {
    boardState = ['', '', '', '', '', '', '', '', ''];
    gameActive = true;
    currentPlayer = 'X';
    statusDisplay.innerText = '';
    createBoard();
});

// Initialize the game
createBoard();
